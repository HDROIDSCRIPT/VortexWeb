<?php

// Database configuration
$servername = "mysql1.serv00.com";
$username = "m8455_vortexweb";
$password = "Hola2000";
$dbname = "m8455_vortexweb";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

?>
