<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>VortexWeb - Website Hosting</title>
    <style>
        body {
            background-color: #ffffff;
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            opacity: 0;
            animation: fadeIn 1s ease-in-out forwards;
        }

        header {
            width: 100%;
            background-color: #f2f2f2;
            padding: 15px 0;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        #container {
            text-align: center;
            margin-top: 20px;
        }

        h1 {
            border-bottom: 2px solid #800080;
            padding-bottom: 10px;
            margin-bottom: 20px;
        }

        button {
            background-color: #800080;
            color: #ffffff;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background-color: #4b004b;
        }

        .logo img {
            max-width: 150px;
            height: auto;
        }

        .auth-buttons {
            display: flex;
            gap: 10px;
        }

        .auth-buttons a {
            text-decoration: none;
            color: #800080;
            padding: 10px 20px;
            border: 1px solid #800080;
            border-radius: 8px;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }

        .auth-buttons a:hover {
            background-color: #800080;
            color: #ffffff;
        }

        @keyframes fadeIn {
            to {
                opacity: 1;
            }
        }
    </style>
<script>
    function redirectToWebsiteBuilder() {
        // Replace 'your-website-builder-url' with the actual URL where you want to redirect
        window.location.href = '/Register/';
    }
</script>

</head>
<body>
    <header>
        <div class="logo">
            <img src="images/logo.png" alt="VortexWeb Logo">
        </div>
        <div class="auth-buttons">
            <a href="/Login/" role="button">Login</a>
            <a href="/Register/" role="button">Register</a>
        </div>
    </header>

    <div id="container">
        <h1>Welcome to VortexWeb</h1>
        <p>Free website hosting</p>
        <button class="uicorner" onclick="redirectToWebsiteBuilder()">Start Making Websites</button>
    </div>
</body>
</html>
