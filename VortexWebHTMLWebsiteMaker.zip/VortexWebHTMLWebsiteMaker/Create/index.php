<?php
session_start();
include('../config.php');

// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    header("Location: ../Login/"); // Redirect to login page if not logged in
    exit();
}

$username = $_SESSION['username'];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $websiteName = $_POST['website_name'];
    
    // Anti-slur system: List of forbidden words
    $forbiddenWords = ['badword1', 'badword2', 'badword3'];

    // Check if the website name contains any forbidden words
    foreach ($forbiddenWords as $word) {
        if (stripos($websiteName, $word) !== false) {
            echo "Website name contains forbidden words. Please choose another name.";
            exit();
        }
    }

    // Perform database insertion
    $sql = "INSERT INTO websites (user_id, name) VALUES ((SELECT id FROM users WHERE username = '$username'), '$websiteName')";

    if ($conn->query($sql) === TRUE) {
        // Create a folder for the website
        $websiteFolder = "/websites/" . $websiteName;
        $websiteFolderPath = $_SERVER['DOCUMENT_ROOT'] . $websiteFolder;

        if (!file_exists($websiteFolderPath)) {
            mkdir($websiteFolderPath, 0777, true);

            // Create index.html with "Hello, World!" content
            $indexFileContent = "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"UTF-8\">\n<title>$websiteName - VortexWeb</title>\n</head>\n<body>\n<h1>Hello, World!</h1>\n</body>\n</html>";
            
            file_put_contents($websiteFolderPath . "/index.html", $indexFileContent);

            echo "Website created successfully!";
        } else {
            echo "Error: Website folder already exists.";
        }
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create Website - VortexWeb</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        #container {
            text-align: center;
        }

        h1 {
            color: #800080;
        }

        form {
            max-width: 300px;
            margin: 20px auto;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #800080;
        }

        input {
            width: 100%;
            padding: 8px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        button {
            background-color: #800080;
            color: #ffffff;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background-color: #4b004b;
        }
    </style>
</head>
<body>
    <div id="container">
        <h1>Create Your Website</h1>
        <form action="../Create/index.php" method="post">
            <label for="website_name">Website Name:</label>
            <input type="text" id="website_name" name="website_name" required>

            <button type="submit" class="uicorner">Create Website</button>
        </form>
    </div>
</body>
</html>
