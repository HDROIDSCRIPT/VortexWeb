<?php
include('../config.php');

session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../Login/"); // Replace with the URL of your login page
    exit();
}

$username = $_SESSION['username'];

// Fetch user's websites from the database
$sql = "SELECT * FROM websites WHERE user_id = (SELECT id FROM users WHERE username = '$username')";
$result = $conn->query($sql);

$websites = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $websites[] = $row;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - VortexWeb</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        #container {
            text-align: center;
        }

        h1 {
            color: #800080;
        }

        .website-list {
            list-style: none;
            padding: 0;
        }

        .website-item {
            border: 1px solid #ddd;
            margin: 10px;
            padding: 10px;
            background-color: #fff;
            border-radius: 8px;
            cursor: pointer; /* Add cursor pointer for clickable effect */
        }

        button {
            background-color: #800080;
            color: #ffffff;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 20px;
        }

        button:hover {
            background-color: #4b004b;
        }
    </style>
</head>
<body>
    <div id="container">
        <h1>Welcome, <?php echo $username; ?>!</h1>

        <h2>Your Websites:</h2>
        <ul class="website-list">
            <?php foreach ($websites as $website): ?>
                <li class="website-item" onclick="location.href='/Configure/?website=<?php echo $website['name']; ?>';">
                    <strong><?php echo $website['name']; ?></strong><br>
                    URL: <?php echo $website['url']; ?><br>
                    Created at: <?php echo $website['created_at']; ?>
                </li>
            <?php endforeach; ?>
        </ul>

        <button onclick="location.href='/Create/';">Create Website</button>
    </div>
</body>
</html>
