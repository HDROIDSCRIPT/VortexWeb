<?php
session_start();
include('../config.php');

if (!isset($_SESSION['username'])) {
    header("Location: ../Login/"); // Redirect to login page if not logged in
    exit();
}

$username = $_SESSION['username'];

$websiteName = isset($_GET['website']) ? $_GET['website'] : null;
$fileName = isset($_GET['file']) ? $_GET['file'] : null;

if (!$websiteName || !$fileName) {
    header("Location: ../Home/"); // Redirect to home if the website or file names are not provided
    exit();
}

$sql = "SELECT * FROM websites WHERE user_id = (SELECT id FROM users WHERE username = '$username') AND name = '$websiteName'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $website = $result->fetch_assoc();
} else {
    header("Location: ../Home/"); // Redirect to home if the website is not found or doesn't belong to the user
    exit();
}

$websiteFolderPath = $_SERVER['DOCUMENT_ROOT'] . "/websites/$websiteName/";
$filePath = $websiteFolderPath . $fileName;

function getFileContent($filePath) {
    return file_get_contents($filePath);
}

$fileContent = getFileContent($filePath);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit File - VortexWeb</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        #container {
            text-align: center;
        }

        h1 {
            color: #800080;
            margin-bottom: 20px;
        }

        textarea {
            width: 80%;
            height: 300px;
            margin: 20px;
        }

        button {
            background-color: #800080;
            color: #ffffff;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
        }

        button:hover {
            background-color: #4b004b;
        }
    </style>
</head>
<body>
    <div id="container">
        <h1>Edit File - <?php echo $fileName; ?></h1>

        <form method="post" action="">
            <textarea name="file_content"><?php echo htmlspecialchars($fileContent); ?></textarea>
            <br>
            <button type="submit" name="save">Save Changes</button>
        </form>

        <button onclick="location.href='editor.php?website=<?php echo $websiteName; ?>';">Back to File Editor</button>
    </div>
</body>
</html>

<?php
// Save changes to the file
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['save'])) {
    $content = $_POST['file_content'];
    file_put_contents($filePath, $content);
}
?>
