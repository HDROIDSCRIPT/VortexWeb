<?php
session_start();
include('../config.php');

if (!isset($_SESSION['username'])) {
    header("Location: ../Login/"); // Redirect to login page if not logged in
    exit();
}

$username = $_SESSION['username'];

$websiteName = isset($_GET['website']) ? $_GET['website'] : null;

if (!$websiteName) {
    header("Location: ../Home/"); // Redirect to home if the website name is not provided
    exit();
}

$sql = "SELECT * FROM websites WHERE user_id = (SELECT id FROM users WHERE username = '$username') AND name = '$websiteName'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $website = $result->fetch_assoc();
} else {
    header("Location: ../Home/"); // Redirect to home if the website is not found or doesn't belong to the user
    exit();
}

$websiteFolderPath = $_SERVER['DOCUMENT_ROOT'] . "/websites/$websiteName/";

function getFileList($folderPath) {
    $files = [];
    if (is_dir($folderPath)) {
        $dirContents = scandir($folderPath);
        foreach ($dirContents as $file) {
            if ($file != '.' && $file != '..' && is_file($folderPath . $file)) {
                $files[] = $file;
            }
        }
    }
    return $files;
}

function createFolder($folderPath, $folderName) {
    $newFolderPath = $folderPath . $folderName;
    if (!is_dir($newFolderPath)) {
        mkdir($newFolderPath);
        return true;
    }
    return false;
}

function createFile($folderPath, $fileName, $fileContent) {
    $newFilePath = $folderPath . $fileName;
    $allowedExtensions = ['html', 'css', 'txt'];
    $extension = pathinfo($newFilePath, PATHINFO_EXTENSION);
    if (in_array(strtolower($extension), $allowedExtensions) && !file_exists($newFilePath)) {
        file_put_contents($newFilePath, $fileContent);
        return true;
    }
    return false;
}

function deleteFile($filePath) {
    if (file_exists($filePath)) {
        unlink($filePath);
        return true;
    }
    return false;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['create_folder'])) {
        $folderName = $_POST['folder_name'];
        createFolder($websiteFolderPath, $folderName);
    } elseif (isset($_POST['create_file'])) {
        $fileName = $_POST['file_name'];
        $fileContent = $_POST['file_content'];
        createFile($websiteFolderPath, $fileName, $fileContent);
    } elseif (isset($_POST['upload_file'])) {
        $uploadedFile = $_FILES['uploaded_file'];
        $fileName = $uploadedFile['name'];
        $fileTempPath = $uploadedFile['tmp_name'];
        $fileDestPath = $websiteFolderPath . $fileName;
        move_uploaded_file($fileTempPath, $fileDestPath);
    } elseif (isset($_POST['delete_file'])) {
        $fileToDelete = $_POST['file_to_delete'];
        deleteFile($websiteFolderPath . $fileToDelete);
    }
}

$fileList = getFileList($websiteFolderPath);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>File Editor - VortexWeb</title>
    <style>
        /* Your existing styles remain unchanged */
body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        #container {
            text-align: center;
        }

        h1 {
            color: #800080;
            margin-bottom: 20px;
        }

        ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }

        li {
            margin: 10px;
        }

        a {
            color: #4b004b;
            text-decoration: none;
            font-weight: bold;
        }

        button {
            background-color: #800080;
            color: #ffffff;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 20px;
        }

        button:hover {
            background-color: #4b004b;
        }
        form {
            margin-top: 20px;
        }

        label {
            display: block;
            margin-bottom: 8px;
            color: #800080;
        }

        input[type="text"] {
            width: 80%;
            padding: 8px;
            margin-bottom: 15px;
            box-sizing: border-box;
        }

        textarea {
            width: 80%;
            height: 100px;
            margin: 10px 0;
        }
    </style>
</head>
<body>
    <div id="container">
        <h1>File Editor - <?php echo $websiteName; ?></h1>

        <ul>
            <?php foreach ($fileList as $file): ?>
                <li>
                    <a href="EditFile.php?website=<?php echo $websiteName; ?>&file=<?php echo urlencode($file); ?>"><?php echo $file; ?></a>
                    <form method="post" action="">
                        <input type="hidden" name="file_to_delete" value="<?php echo $file; ?>">
                        <button type="submit" name="delete_file">Delete</button>
                    </form>
                </li>
            <?php endforeach; ?>
        </ul>

        <form method="post" action="">
            <label for="folder_name">Create Folder:</label>
            <input type="text" id="folder_name" name="folder_name" required>
            <button type="submit" name="create_folder">Create</button>
        </form>

        <form method="post" action="">
            <label for="file_name">Create File:</label>
            <input type="text" id="file_name" name="file_name" required>
            <textarea name="file_content" required></textarea>
            <button type="submit" name="create_file">Create</button>
        </form>

        <form method="post" action="" enctype="multipart/form-data">
            <label for="uploaded_file">Upload File:</label>
            <input type="file" id="uploaded_file" name="uploaded_file" required>
            <button type="submit" name="upload_file">Upload</button>
        </form>

        <button onclick="location.href='../Home/';">Back to Home</button>
    </div>
</body>
</html>
