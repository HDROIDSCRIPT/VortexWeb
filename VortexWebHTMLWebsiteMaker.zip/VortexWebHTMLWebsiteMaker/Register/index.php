<?php
include('../config.php');
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require '../PHPMailer/src/Exception.php';
require '../PHPMailer/src/PHPMailer.php';
require '../PHPMailer/src/SMTP.php';

// Check if the user is already logged in
session_start();
if(isset($_SESSION['username'])){
    header("Location: ../Home/"); // Replace with the desired redirect URL
    exit();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];

    // Check if the user already exists
    $checkUserSql = "SELECT * FROM users WHERE username='$username' OR email='$email'";
    $result = $conn->query($checkUserSql);

    if ($result->num_rows > 0) {
        echo "User already exists.";
    } else {
        // Generate a unique verification token
        $verificationToken = md5(uniqid(rand(), true));

        // Perform database insertion
        $sql = "INSERT INTO users (username, email, password, verification_token) VALUES ('$username', '$email', '$password', '$verificationToken')";

        if ($conn->query($sql) === TRUE) {
            // Send a welcome email with the verification link
            sendVerificationEmail($email, $verificationToken, $username);

            echo "Registration successful! Please check your email for the verification link.";
        } else {
            echo "Error: " . $sql . "<br>" . $conn->error;
        }
    }
}

$conn->close();

function sendVerificationEmail($to, $token, $username) {
    $mail = new PHPMailer(true);
    try {
        // Server settings
        $mail->isSMTP();
        $mail->Host       = 'mail1.serv00.com'; // Replace with your SMTP server
        $mail->SMTPAuth   = true;
        $mail->Username   = 'name@website.serv00.net'; // Replace with your SMTP username
        $mail->Password   = 'emailpassword'; // Replace with your SMTP password
        $mail->SMTPSecure = 'ssl'; // Use 'tls' or 'ssl' based on your server configuration
        $mail->Port       = 465; // Use the appropriate port for your server

        // Recipients
        $mail->setFrom('name@website.serv00.net', 'VortexWeb');
        $mail->addAddress($to);

        // Content
        $mail->isHTML(true);
        $mail->Subject = 'Welcome to VortexWeb - Verify Your Email';

        // Additional content in the email
        $mail->Body    = "
            <p>Dear $username,</p>
            <p>Thank you for registering with VortexWeb! We're excited to have you on board.</p>
            <p>Click the following link to verify your email: <a href='https://hdroidev.serv00.net/Verify/index.php?token=$token'>Verify Email</a></p>
            <p>Once verified, you'll be able to log in and explore all the features of VortexWeb.</p>
            <p>Best regards,<br>VortexWeb Team</p>
        ";

        $mail->send();
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
    }
}
?>

<style>
/* styles.css */

body {
    font-family: Arial, sans-serif;
    background-color: #f2f2f2;
    margin: 0;
    padding: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
}

#container {
    text-align: center;
}

h1 {
    color: #800080;
}

form {
    max-width: 300px;
    margin: 20px auto;
}

label {
    display: block;
    margin-bottom: 8px;
    color: #800080;
}

input {
    width: 100%;
    padding: 8px;
    margin-bottom: 15px;
    box-sizing: border-box;
}

button {
    background-color: #800080;
    color: #ffffff;
    padding: 10px 20px;
    font-size: 16px;
    border: none;
    border-radius: 8px;
    cursor: pointer;
}

button:hover {
    background-color: #4b004b;
}
</style>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register - VortexWeb</title>
    <link rel="stylesheet" href="styles.css"> <!-- Include your main CSS file here -->
</head>
<body>
    <div id="container">
        <h1>Register</h1>
        <form action="../Register/" method="post">
            <label for="username">Username:</label>
            <input type="text" id="username" name="username" required>

            <label for="email">Email:</label>
            <input type="email" id="email" name="email" required>

            <label for="password">Password:</label>
            <input type="password" id="password" name="password" required>

            <button type="submit" class="uicorner">Register</button>
        </form>
    </div>
</body>
</html>
