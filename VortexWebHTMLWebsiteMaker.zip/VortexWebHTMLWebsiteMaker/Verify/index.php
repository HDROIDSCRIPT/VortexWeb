<?php
include('../config.php');

if (isset($_GET['token'])) {
    $token = $_GET['token'];

    // Check if the token exists in the database
    $sql = "SELECT * FROM users WHERE verification_token = '$token'";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        // Mark the user as verified
        $updateSql = "UPDATE users SET verified = 1, verification_token = '' WHERE verification_token = '$token'";
        if ($conn->query($updateSql) === TRUE) {
            echo "Email verification successful! You can now log in.";
        } else {
            echo "Error updating record: " . $conn->error;
        }
    } else {
        echo "Invalid verification token.";
    }
} else {
    echo "Invalid verification token.";
}

$conn->close();
?>
