// JavaScript Document

// Change text in input boxes & text areas to be blank on focus

 $(document).ready(function() {  
	
	$('input[type="text"]').addClass("idleField");
	$('input[type="text"]').focus(function() {
		$(this).removeClass("idleField").addClass("focusField");
		if (this.value == this.defaultValue){ 
			this.value = '';
		}
		if(this.value != this.defaultValue){
			this.select();
		}
	});
	$('input[type="text"]').blur(function() {
		$(this).removeClass("focusField").addClass("idleField");
		if ($.trim(this.value) == ''){
			this.value = (this.defaultValue ? this.defaultValue : '');
		}
	});

	$('textarea').addClass("idleField");
	$('textarea').focus(function() {
		$(this).removeClass("idleField").addClass("focusField");
		if (this.value == this.defaultValue){ 
			this.value = '';
		}
		if(this.value != this.defaultValue){
			this.select();
		}
	});
	$('textarea').blur(function() {
		$(this).removeClass("focusField").addClass("idleField");
		if ($.trim(this.value) == ''){
			this.value = (this.defaultValue ? this.defaultValue : '');
		}
	});	


// Validate quick enquiry form

	$("#quickenquiry").validate({
		debug: false,
		rules: {
			quickname: "required",
			quickemail: {
				required: true,
				email: true
			},
			quickmessage: {
				required: true,
				maxlength: 500
			}
			
		},
		messages: {
			quickname: "",
			quickemail: "",
			quickmessage: "",
		},
					
		submitHandler: function(form) {
	$.post('scripts/process.html', $("#quickenquiry").serialize());
			// do other stuff for a valid form 
    $("#quickenquiry").delay(800).fadeOut(400)
      $('#results').css("visibility", "visible") 
	  $('#results').hide() 
	  $("#results").delay(800).fadeIn(400)
	  $("#results").delay(4000).fadeOut(400)
	  $("#quickenquiry").delay(4400).fadeIn(600)  

		}
	});

 // Make results Div hidden again
 $('#results').click(function(){
	  $('#results').css("visibility", "hidden")  
		});



	
});
 

 
 
 
 
 