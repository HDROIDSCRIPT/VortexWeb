<?php
include('../config.php');

session_start();
if (!isset($_SESSION['username'])) {
    header("Location: ../Login/"); // Redirect to login page if not logged in
    exit();
}

$username = $_SESSION['username'];

// Get the website name from the query parameter
$websiteName = isset($_GET['website']) ? $_GET['website'] : null;

if (!$websiteName) {
    // Redirect to home if the website name is not provided
    header("Location: ../Home/"); // Replace with the URL of your home page
    exit();
}

// Fetch the website details from the database
$sql = "SELECT * FROM websites WHERE user_id = (SELECT id FROM users WHERE username = '$username') AND name = '$websiteName'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    $website = $result->fetch_assoc();
} else {
    // Redirect to home if the website is not found
    header("Location: ../Home/"); // Replace with the URL of your home page
    exit();
}

// Function to delete the website and its folder
function deleteWebsite($conn, $websiteName, $username) {
    $websiteFolder = $_SERVER['DOCUMENT_ROOT'] . "/websites/" . $websiteName;

    // Remove the folder and its contents
    if (file_exists($websiteFolder)) {
        array_map('unlink', glob("$websiteFolder/*.*"));
        rmdir($websiteFolder);
    }

    // Remove the website entry from the database
    $deleteSql = "DELETE FROM websites WHERE name = '$websiteName' AND user_id = (SELECT id FROM users WHERE username = '$username')";
    $conn->query($deleteSql);
}

// Handle delete website button click
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['delete_website'])) {
    deleteWebsite($conn, $websiteName, $username);
    header("Location: ../Home/"); // Redirect to home after deletion
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configure Website - VortexWeb</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
            margin: 0;
            padding: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100vh;
        }

        #container {
            text-align: center;
        }

        h1 {
            color: #800080;
        }

        .website-details {
            border: 1px solid #ddd;
            margin: 10px;
            padding: 20px;
            background-color: #fff;
            border-radius: 8px;
        }

        button {
            background-color: #800080;
            color: #ffffff;
            padding: 10px 20px;
            font-size: 16px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            margin-top: 20px;
        }

        button:hover {
            background-color: #4b004b;
        }
    </style>
</head>
<body>
    <div id="container">
        <h1>Configure Website - <?php echo $website['name']; ?></h1>

        <div class="website-details">
            <p><strong>Website Name:</strong> <?php echo $website['name']; ?></p>
            <p><strong>URL:</strong> <?php echo $website['url']; ?></p>
            <p><strong>Created at:</strong> <?php echo $website['created_at']; ?></p>
            <!-- Add more configuration details as needed -->
        </div>

     <!-- Existing code above this line remains unchanged -->

<form method="post" action="/FileEditor/index.php?website=<?php echo $websiteName; ?>">
    <button type="submit" name="edit_files">File Editor</button>
</form>

<!-- Existing code below this line remains unchanged -->


<form method="post" action="">
    <button type="submit" name="delete_website" onclick="return confirm('Are you sure you want to delete this website?')">Delete Website</button>
</form>

<!-- Existing code below this line remains unchanged -->


        <button onclick="location.href='../Home/';">Back to Home</button>
    </div>
</body>
</html>
